CREATE TABLE IF NOT EXISTS hive.ml_tmp_db.wgame_bundle_dynamic_pricing_feature_common (
    role_id varchar,
    acc_id varchar,
    feature array(ROW(fname VARCHAR, fvalue VARCHAR)),
    feature_group varchar,
    dt varchar
) WITH (
    FORMAT = 'PARQUET',
    partitioned_by = ARRAY['feature_group','dt']
);

DELETE FROM hive.ml_tmp_db.wgame_bundle_dynamic_pricing_feature_common
WHERE dt = '{{ ds }}'
AND feature_group = 'common';

INSERT INTO hive.ml_tmp_db.wgame_bundle_dynamic_pricing_feature_common
SELECT 
    role_id
    , acc_id
    , map_entries(TRANSFORM_VALUES(MAP_FILTER(f, (x, v) -> CONTAINS(SPLIT('{{ feature_list }}', ','), x)), (k,v) -> v[1]))
    , 'common'
    , dt
FROM (
    SELECT
        role_id, acc_id, dt, SPLIT_TO_MULTIMAP(feature, U&'\0002', U&'\0003') AS f
        -- , TRANSFORM(
        --     SPLIT(feature, U&'\0002') 
        --     , x -> CAST(ROW(SPLIT_PART(x, U&'\0003', 1), SPLIT_PART(x, U&'\0003', 2)) AS ROW(fname VARCHAR, fvalue VARCHAR))
        -- ) AS f
    FROM hive."10048_ml_dw".bundle_price_role_common_feature_dd 
    WHERE dt = '{{ ds }}' 
        AND feature_group = 'attribute'
) as a