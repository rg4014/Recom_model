SELECT 
    CONCAT_WS('@', a.acc_id, a.role_id,a.dt) as sampleid
    , CONCAT_WS(U&'\0002', ARRAY_AGG(a.feature)) as feature
FROM (
    SELECT *
    FROM hive."10048_ml_dw".role_common_feature_dd
    WHERE dt BETWEEN '{{ start_dt }}' AND '{{ end_dt }}'
        AND feature_group in ('attribute', 'trigger_bundle_price','resource','item')
) AS a
INNER JOIN (
    SELECT open_id AS acc_id, user_id AS role_id, dt
    FROM hive."10048_oss_bi_dw".wgame_trigger_bundle_v2 
    WHERE DATE(dt) BETWEEN DATE_ADD('day',1,'{{ start_dt }}') AND DATE_ADD('day',1,'{{ end_dt }}')
        AND action = 'spc_bundle_buy'
        AND bundle_price = '9999'
) as b
on a.acc_id = b.acc_id 
    and a.role_id = b.role_id 
    and a.dt = DATE_FORMAT(DATE_ADD('day',-1,b.dt),'%Y-%m-%d')
GROUP BY a.acc_id, a.role_id,a.dt