CREATE TABLE IF NOT EXISTS hive.ml_tmp_db.wgame_bunlde_sequence_sample (
    open_id varchar,
    user_id varchar,
    trigger_type varchar,
    max7pay varchar,
    feature VARCHAR,
    dt varchar
)  WITH (
    FORMAT = 'PARQUET',
    partitioned_by = ARRAY['dt']
);

DELETE FROM hive.ml_tmp_db.wgame_bunlde_sequence_sample
WHERE dt = '{{ ds }}';

INSERT INTO hive.ml_tmp_db.wgame_bunlde_sequence_sample
WITH future AS (
    SELECT
        open_id,
        user_id,
        trigger_type,
        MAX_BY(bundle_price, TRY_CAST(bundle_price AS integer)) AS max7pay
    FROM
        hive."10048_oss_bi_dw".wgame_trigger_bundle_v2
    WHERE
        DATE(dt) BETWEEN DATE_ADD('day', 1, '{{ ds }}') AND DATE_ADD('day', 7, '{{ ds }}')
        AND action = 'spc_bundle_buy'
        AND bundle_price != '99'
        AND os_type != ''
        AND server_id LIKE 'global%'
    GROUP BY open_id, user_id, trigger_type
)

SELECT 
    future.open_id
    , future.user_id
    , future.trigger_type
    , future.max7pay
    , CONCAT_WS(U&'\0002', b.feature, c.feature) AS feature
    , '{{ ds }}' AS dt
FROM future
LEFT JOIN (
    SELECT *
    FROM hive."10048_ml_dw".bundle_price_role_common_feature_v2_dd 
    WHERE dt = '{{ ds }}'
        AND feature_group = 'purchase_bundle_history'
) as b
ON future.open_id = b.acc_id
    AND future.user_id = b.role_id
INNER JOIN (
    SELECT acc_id, role_id, CONCAT_WS(U&'\0002', ARRAY_AGG(feature)) as feature
    FROM hive.ml_tmp_db.wgame_bundle_dynamic_pricing_feature_res_ratityv2
    WHERE dt = '{{ ds }}'
    GROUP BY acc_id, role_id
) AS c
ON future.open_id = c.acc_id
    AND future.user_id = c.role_id

