
WITH bundle_pop_data AS (
    SELECT *
    FROM (
        SELECT *, ROW_NUMBER() OVER (PARTITION BY user_id, open_id, bundle_id, trace_id ORDER BY event_time DESC) AS rnk
        FROM hive."10048_oss_bi_dw".wgame_trigger_bundle_v2
        WHERE dt BETWEEN '{{ start_dt }}' AND '{{ end_dt }}'
            AND action = 'campaign_stage_trigger'
            AND trigger_type LIKE '%advancecard%'
    ) AS tmp
    WHERE rnk = 1
)

, bundle_buy_data AS (
    SELECT *
    FROM (
        SELECT *, ROW_NUMBER() OVER (PARTITION BY user_id, open_id, bundle_id, trace_id ORDER BY event_time DESC) AS rnk
        FROM hive."10048_oss_bi_dw".wgame_trigger_bundle_v2
        WHERE dt BETWEEN '{{ start_dt }}' AND '{{ end_dt }}'
            AND action = 'spc_bundle_buy'
            AND trigger_type LIKE '%advancecard%'
    ) AS tmp
    WHERE rnk = 1
)

, bundle_label AS (
    SELECT 
        a.*
        , IF(b.bundle_id IS NOT NULL,1,0) AS if_buy_pop_gift 
    FROM bundle_pop_data AS a
    LEFT JOIN bundle_buy_data AS b
    ON a.open_id = b.open_id
        AND a.user_id = b.user_id
        AND a.trace_id = b.trace_id
        AND a.bundle_id = b.bundle_id
)


SELECT 
    CRC32(TO_UTF8(CONCAT_WS('@', a.open_id, a.user_id, a.bundle_id, a.trace_id, a.dt))) AS sampleid
    , CONCAT_WS(U&'\0002', ARRAY_AGG(b.feature)) AS feature
    , a.if_buy_pop_gift
    , a.bundle_price
FROM bundle_label AS a
LEFT JOIN (
    SELECT *, DATE_FORMAT(DATE_ADD('day', 1,dt), '%Y-%m-%d') AS dt2
    FROM hive."10048_ml_dw".role_common_feature_dd
    WHERE dt BETWEEN DATE_FORMAT(DATE_ADD('day', -1,'{{ start_dt }}'), '%Y-%m-%d') AND DATE_FORMAT(DATE_ADD('day', -1,'{{ end_dt }}'), '%Y-%m-%d')
        AND feature_group in ('attribute', 'trigger_bundle_price','resource','item')
) AS b
ON a.open_id = b.acc_id
    AND a.user_id = b.role_id
    AND a.dt = b.dt2
GROUP BY a.open_id, a.user_id, a.bundle_id, a.trace_id, a.dt, a.if_buy_pop_gift, a.bundle_price