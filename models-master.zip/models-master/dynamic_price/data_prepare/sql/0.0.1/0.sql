CREATE TABLE IF NOT EXISTS hive.ml_tmp_db.wgame_common_feature_trigger_bundle_u2i_feature (
    acc_id varchar,
    role_id varchar, 
    -- trigger_type varchar,
    -- bundle_price varchar,
    feature varchar,
    update_time varchar,
    feature_group varchar,
    dt varchar
) WITH (
    FORMAT = 'PARQUET',
    partitioned_by = ARRAY['update_time', 'feature_group','dt']
);

DELETE FROM hive.ml_tmp_db.wgame_common_feature_trigger_bundle_u2i_feature
WHERE update_time = '{{ current_timestamp }}'
    AND feature_group = 'trigger_bundle_price_u2i'
    AND dt =  DATE_FORMAT('{{ current_timestamp }}', '%Y-%m-%d');

INSERT INTO hive.ml_tmp_db.wgame_common_feature_trigger_bundle_u2i_feature

WITH base0 AS (
    SELECT *
        , DATE_DIFF('hour', event_time, '{{ current_timestamp }}') AS itvl
        , concat(user_id,open_id,bundle_id,trigger_type,trigger_condition,bundle_price,trace_id) AS unique_id
    FROM hive."10048_oss_bi_dw".wgame_trigger_bundle_v2
    WHERE DATE(dt) BETWEEN DATE_ADD('day', -15, '{{ current_timestamp }}') AND DATE_ADD('day', -1, '{{ current_timestamp }}')
)



, base1 AS (
    SELECT 
        t1.*,
        t2.p,
        row_number() over ( partition by open_id, user_id, trigger_type, bundle_price, p order by event_time desc ) as rnk
    FROM (
        SELECT 
            t.*
            , IF(b.unique_id is not null, 1, 0) AS if_buy_pop_gift
            , FILTER(ARRAY[0, 3, 12, 24, 72, 7*24, 14*24, 365  * 24], x -> x < t.itvl) AS periods
        FROM (SELECT * FROM base0 WHERE action = 'campaign_stage_trigger') AS t
        LEFT JOIN (SELECT * FROM base0 WHERE action = 'spc_bundle_buy') AS b
        ON t.unique_id = b.unique_id
            AND t.dt = b.dt
        WHERE CONTAINS(ARRAY['99','499','999','1499','1999','2999','4999','9999'], t.bundle_price)
    ) t1
    CROSS JOIN UNNEST (t1.periods) t2(p)
    WHERE p < 14 * 24 + 1
)

, item_stats AS (
    SELECT 
        t.trigger_type,
        t.bundle_price,
        t.p,
        TRY_CAST(SUM(if_buy_pop_gift) AS DOUBLE) AS bought_cnt,
        TRY_CAST(COUNT(1) AS DOUBLE) AS pop_cnt
        -- TRY_CAST(COUNT_IF(b.unique_id is not null) AS DOUBLE) / TRY_CAST(COUNT(1) AS DOUBLE) AS cv
    FROM base1 AS t
    GROUP BY t.trigger_type, t.bundle_price, t.p
)

, user_stats AS (
    SELECT
        t1.open_id
        , t1.user_id
        , t1.trigger_type
        , t1.bundle_price
        , TRY_CAST(SUM(t1.if_buy_pop_gift) AS DOUBLE) AS bought_cnt
        , TRY_CAST(COUNT(1) AS DOUBLE) AS pop_cnt
        , t1.p
        , SUM(IF(rnk=1,t1.if_buy_pop_gift,0)) AS bought_last_pop
        , FORMAT('p%dh_%s_', t1.p, t1.bundle_price) AS prefix
    FROM base1 AS t1
    GROUP BY t1.open_id, t1.user_id, t1.trigger_type, t1.bundle_price, t1.p
)

, feature AS (

    SELECT 
        t1.open_id 
        , t1.user_id
        , t1.trigger_type
        , CONCAT(
            'r_trigger_price_stats_',
            t1.trigger_type,
            U&'\0003',
            CONCAT_WS(
                U&'\0004',
                FILTER(
                    FLATTEN(
                        ARRAY[
                            ARRAY_AGG( IF(t1.bought_cnt > 0,  CONCAT(t1.prefix, 'cvr_in5e-2bucket', FORMAT('%.0f', t1.bought_cnt / t1.pop_cnt / 0.05)), CONCAT(t1.prefix, 'never_bought')) ),
                            ARRAY_AGG( CONCAT(t1.prefix, 'item_ctx_cvr', FORMAT('%.2f', t2.bought_cnt / t2.pop_cnt)) ),
                            ARRAY_AGG( IF(t1.bought_last_pop>0, CONCAT(t1.prefix, 'bought_last_time'), null) ),
                            ARRAY_AGG( IF(t1.bought_cnt / t1.pop_cnt >= (t2.bought_cnt / t2.pop_cnt + 0.001), CONCAT(t1.prefix, 'cv_geq_ctx'), null) ),
                            ARRAY_AGG( IF(t1.bought_cnt / t1.pop_cnt <= (t2.bought_cnt / t2.pop_cnt - 0.001), CONCAT(t1.prefix, 'cv_leq_ctx'), null) )
                        ]
                    )
                    , x -> x IS NOT NULL
                )
                
            )
        ) as f
    FROM user_stats AS t1
    LEFT JOIN item_stats AS t2
    ON t1.trigger_type = t2.trigger_type 
        AND t1.bundle_price = t2.bundle_price 
        AND t1.p = t2.p
    GROUP BY t1.open_id, t1.user_id, t1.trigger_type
)



SELECT
    open_id 
    , user_id
    , CONCAT_WS(U&'\0002', ARRAY_AGG(f)) AS feature
    , '{{ current_timestamp }}' AS update_time
    , 'trigger_type_price_stats' AS feature_group
    , DATE_FORMAT('{{ current_timestamp }}', '%Y-%m-%d') AS dt
FROM feature
GROUP BY open_id , user_id




