
drop table hive.ml_tmp_db.wgame_trigger_bundle_offline_experiment_0411_pairwise_sample;

create table IF NOT EXISTS hive.ml_tmp_db.wgame_trigger_bundle_offline_experiment_0411_pairwise_sample (
    pos_trigger_type varchar,
    neg_trigger_type varchar,
    pos_bundle_price varchar,
    neg_bundle_price varchar,
    pos_gift_contents array(ROW(item_goods_id varchar, item_goods_count bigint)),
    neg_gift_contents array(ROW(item_goods_id varchar, item_goods_count bigint)),
    pos_feature varchar,
    neg_feature varchar,
    grp varchar,
    idxs array(integer)
);




INSERT INTO hive.ml_tmp_db.wgame_trigger_bundle_offline_experiment_0411_pairwise_sample
SELECT 
    pos.trigger_type
    , neg.trigger_type
    , pos.bundle_price
    , neg.bundle_price
    , pos.gift_contents
    , neg.gift_contents
    , pos.feature
    , neg.feature
    , 'easy'
    , ARRAY[pos.sampleid, neg.sampleid]
FROM (
    SELECT * 
    FROM hive.ml_tmp_db.wgame_trigger_bundle_offline_experiment_0411
    WHERE if_buy_pop_gift = 1
        and grp = 'train'
) as pos
CROSS JOIN (
    SELECT a.*
    FROM hive.ml_tmp_db.wgame_trigger_bundle_offline_experiment_0411 as a
    WHERE a.if_buy_pop_gift = 0
        and a.grp = 'train'
) as neg
LIMIT 100000;


INSERT INTO hive.ml_tmp_db.wgame_trigger_bundle_offline_experiment_0411_pairwise_sample
SELECT 
    pos.trigger_type
    , neg.trigger_type
    , pos.bundle_price
    , neg.bundle_price
    , pos.gift_contents
    , neg.gift_contents
    , pos.feature
    , neg.feature
    , 'hard-type-1'
    , ARRAY[pos.sampleid, neg.sampleid]
FROM (

    SELECT 
        b.*
    FROM (
        SELECT open_id, user_id,  MAX(bundle_price) as max_price
        FROM hive.ml_tmp_db.wgame_trigger_bundle_offline_experiment_0411
        WHERE if_buy_pop_gift = 1
            and grp = 'train'
        GROUP BY open_id, user_id
    ) AS a
    INNER JOIN (
        SELECT *
        FROM hive.ml_tmp_db.wgame_trigger_bundle_offline_experiment_0411
        WHERE if_buy_pop_gift = 1
            and grp = 'train'
    ) AS b
    ON a.open_id = b.open_id
        AND a.user_id = b.user_id
        AND a.max_price = b.bundle_price
    
) as pos
LEFT JOIN (
    SELECT *
    FROM hive.ml_tmp_db.wgame_trigger_bundle_offline_experiment_0411
    WHERE if_buy_pop_gift = 1
        and grp = 'train'
) as neg
ON pos.open_id = neg.open_id
    AND pos.user_id = neg.user_id
    AND TRY_CAST(pos.bundle_price as int) > TRY_CAST(neg.bundle_price as int);

INSERT INTO hive.ml_tmp_db.wgame_trigger_bundle_offline_experiment_0411_pairwise_sample
SELECT 
    pos.trigger_type
    , neg.trigger_type
    , pos.bundle_price
    , neg.bundle_price
    , pos.gift_contents
    , neg.gift_contents
    , pos.feature
    , neg.feature
    , 'hard-type-2'
    , ARRAY[pos.sampleid, neg.sampleid]
FROM (
    SELECT *
    FROM hive.ml_tmp_db.wgame_trigger_bundle_offline_experiment_0411
    WHERE if_buy_pop_gift = 1
        and grp = 'train'
) as pos
LEFT JOIN (
    SELECT *
    FROM hive.ml_tmp_db.wgame_trigger_bundle_offline_experiment_0411
    WHERE if_buy_pop_gift = 0
        and grp = 'train'
) as neg
ON pos.open_id = neg.open_id
    AND pos.user_id = neg.user_id
    AND TRY_CAST(pos.bundle_price as int) < TRY_CAST(neg.bundle_price as int)


