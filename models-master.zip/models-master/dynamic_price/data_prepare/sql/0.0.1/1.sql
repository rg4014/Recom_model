DROP TABLE IF EXISTS hive.ml_tmp_db.wgame_trigger_bundle_offline_experiment_0411;

CREATE TABLE IF NOT EXISTS hive.ml_tmp_db.wgame_trigger_bundle_offline_experiment_0411 AS 

WITH base AS (
    SELECT *
    FROM (
        SELECT 
            *
            , CONCAT_WS('@',user_id, open_id, bundle_id, trace_id) AS unique_id
            , ROW_NUMBER() OVER (PARTITION BY user_id, open_id, bundle_id, trace_id, action ORDER BY event_time DESC) AS rnk
        FROM hive."10048_oss_bi_dw".wgame_trigger_bundle_v2
        WHERE dt BETWEEN '{{ start_dt }}' AND '{{ end_dt }}'
    ) AS tmp
    WHERE rnk = 1
)

, bundle_label AS (
    SELECT 
        a.*
        , IF(b.unique_id IS NOT NULL,1,0) AS if_buy_pop_gift 
    FROM (SELECT * FROM base WHERE action = 'campaign_stage_trigger') AS a
    LEFT JOIN (SELECT * FROM base WHERE action = 'spc_bundle_buy') AS b
    ON a.unique_id = b.unique_id
)

, t1_feature AS (
    SELECT 
        b.unique_id
        , f.feature
        , row_number() over (partition by b.unique_id, f.feature_group order by f.dt desc) as rnk
    FROM bundle_label as b
    LEFT JOIN (
        SELECT *
        FROM hive."10048_ml_dw".role_common_feature_dd
        WHERE dt BETWEEN DATE_FORMAT(DATE_ADD('day', -1,'{{ start_dt }}'), '%Y-%m-%d') AND DATE_FORMAT(DATE_ADD('day', -1,'{{ end_dt }}'), '%Y-%m-%d')
        AND feature_group in ('attribute', 'trigger_bundle_price','resource','item')
    ) AS f
    ON b.dt > f.dt
        AND b.open_id = f.acc_id
        AND b.user_id = f.role_id
)


SELECT
    b.open_id
    , b.user_id
    , b.server_id
    , b.unique_id
    , b.trigger_type
    , b.gift_contents
    , b.bundle_price
    , b.if_buy_pop_gift
    , t1.feature
    , row_number() over (order by b.unique_id) as sampleid
    , b.recharge
    , IF(crc32(to_utf8(b.unique_id)) % 10 < 2, 'valid', 'train') as grp
FROM bundle_label as b
INNER JOIN (
    SELECT unique_id, CONCAT_WS(U&'\0002', ARRAY_AGG(feature)) AS feature
    FROM t1_feature
    where rnk = 1
    GROUP BY unique_id
) AS t1
ON b.unique_id = t1.unique_id
WHERE b.open_id not like '0-%'







