CREATE TABLE IF NOT EXISTS hive.ml_tmp_db.wgame_bunlde_sequence_feature0626_hashed (
    open_id varchar,
    user_id varchar,
    event_time varchar,
    trigger_type varchar,
    bundle_price varchar,
    unique_id BIGINT,
    gift_contents ARRAY(BIGINT),
    last1bundle ARRAY(BIGINT),
    last2bundle ARRAY(BIGINT),
    last3bundle ARRAY(BIGINT),
    last4bundle ARRAY(BIGINT),
    last5bundle ARRAY(BIGINT),
    max3pay integer,
    max7pay integer,
    label integer,
    dt varchar
)  WITH (
    FORMAT = 'PARQUET',
    partitioned_by = ARRAY['dt']
);

DELETE FROM hive.ml_tmp_db.wgame_bunlde_sequence_feature0626_hashed
WHERE dt = '{{ ds }}';

INSERT INTO hive.ml_tmp_db.wgame_bunlde_sequence_feature0626_hashed
WITH past AS (
    SELECT
        open_id,
        user_id,
        trigger_type,
        MIN(event_time) AS event_time,
        ARBITRARY(gift_contents) AS gift_contents,
        CONTAINS(ARRAY_AGG(ACTION), 'spc_bundle_buy') AS if_buy_boolean,
        bundle_id,
        bundle_price,
        trace_id,
        CONCAT(user_id, open_id, bundle_id, trigger_type, trigger_condition, bundle_price, trace_id) AS unique_id,
        dt
    FROM
        hive."10048_oss_bi_dw".wgame_trigger_bundle_v2
    WHERE
        DATE(dt) BETWEEN DATE('{{ ds }}') AND DATE_ADD('day', 1, '{{ ds }}')
        AND event_time BETWEEN CONCAT('{{ ds }}', ' ', '04:00:00') AND CONCAT(DATE_FORMAT(DATE_ADD('day', 1, '{{ ds }}'),'yyyy-mm-dd'), ' ', '04:00:00')
        AND bundle_price != '99'
        AND os_type != ''
    GROUP BY
        open_id,
        user_id,
        trigger_type,
        bundle_id,
        trace_id,
        bundle_price,
        dt,
        CONCAT(user_id, open_id, bundle_id, trigger_type, trigger_condition, bundle_price, trace_id)
)

, future AS (
    SELECT
        open_id,
        user_id,
        event_time,
        try_cast(bundle_price as integer) as bundle_price,
        CONCAT(user_id, open_id, bundle_id, trigger_type, trigger_condition, bundle_price, trace_id) AS unique_id
    FROM
        hive."10048_oss_bi_dw".wgame_trigger_bundle_v2
    WHERE
        DATE(dt) BETWEEN DATE_ADD('day', 0, '{{ ds }}') AND DATE_ADD('day', 7, '{{ ds }}')
        AND action = 'spc_bundle_buy'
        AND bundle_price != '99'
        AND os_type != ''
)

, label AS (
    SELECT a.*, b.max3pay, b.max7pay
    FROM past as a
    INNER JOIN (
        SELECT 
            past.unique_id,
            MAX(IF(DATE_DIFF('hour', past.event_time, future.event_time) BETWEEN 0 AND 24 * 3, future.bundle_price, 0)) AS max3pay,
            MAX(IF(DATE_DIFF('hour', past.event_time, future.event_time) BETWEEN 0 AND 24 * 7, future.bundle_price, 0)) AS max7pay
        FROM past
        INNER JOIN future
        ON past.open_id = future.open_id
            AND past.user_id = future.user_id
            AND DATE_DIFF('hour', past.event_time, future.event_time) BETWEEN 3 AND 24 * 7
        GROUP BY 1
    ) AS b
    ON a.unique_id = b.unique_id
)

, purchase_history AS (
    SELECT
        o.*,
        label.unique_id,
        DATE_DIFF('hour', o.purchase_time, label.event_time) AS purchase_hour,
        TRY_CAST(JSON_PARSE(item_contents) AS ARRAY(ROW(item_goods_id VARCHAR, item_goods_count DOUBLE))) AS contents,
        ROW_NUMBER() OVER(PARTITION BY label.unique_id ORDER BY o.purchase_time DESC) AS row_num
    FROM (
        SELECT
            *
        FROM
            kudu."10048_stage".order_attr_all_custom_kudu
        WHERE
            year(try_cast(purchase_time AS timestamp)) >= 2023
            AND DATE(try_cast(purchase_time AS timestamp)) BETWEEN DATE_ADD('day', -30, '{{ ds }}') AND DATE_ADD('day', 1, '{{ ds }}')
            AND item_category LIKE '%礼包%'
            AND item_contents != ''
    ) AS o
    INNER JOIN label 
    ON label.open_id = o.acc_id
        AND label.user_id = o.role_id
        AND DATE_DIFF('hour', o.purchase_time, label.event_time) BETWEEN 1 AND 24 * 30
)


, purchase_sequence_raw AS (
    SELECT
        his.unique_id,
        his.row_num AS idx,
        ARBITRARY(his.item_category) AS item_category,
        ARBITRARY(his.price_level) AS price_level,
        ARBITRARY(his.purchase_hour) AS purchase_hour,
        FLATTEN(
            ARRAY_AGG(
                ARRAY[
                    FORMAT('item:%s,bkt:%d', item_id, CAST(TRUNCATE(LOG(2, item.item_goods_count * c.usd_price + 1)) AS INTEGER))
                    , FORMAT('type:%d,bkt:%d', CRC32(TO_UTF8(c.item_type)), CAST(TRUNCATE(LOG(2, item.item_goods_count * c.usd_price + 1)) AS INTEGER))
                ]
            )
        ) AS items
    FROM (
        SELECT *
        FROM purchase_history
        WHERE row_num <= 5
    ) AS his
    CROSS JOIN UNNEST(his.contents) AS item(item_goods_id, item_goods_count)
    INNER JOIN hive."ds_bi_dw".dim_wgame_bundle_item_value_config AS c 
    ON item.item_goods_id = c.item_id
    WHERE
        item.item_goods_count IS NOT NULL
        AND item.item_goods_id <> ''
        AND item.item_goods_id IS NOT NULL
    GROUP BY his.unique_id, his.row_num
)

, purchase_sequence AS (
    SELECT
        unique_id
        , FLATTEN(
            ARRAY_AGG(
                ARRAY[
                    FORMAT('category:%s', CRC32(TO_UTF8(item_category))),
                    FORMAT('price:%d', price_level),
                ] || items
            ) 
            FILTER (WHERE idx = 1)
        ) AS last1bundle
        , FLATTEN(
            ARRAY_AGG(
                ARRAY[
                    FORMAT('category:%s', CRC32(TO_UTF8(item_category))),
                    FORMAT('price:%d', price_level),
                    FORMAT('hour:%d', CAST(TRUNCATE(LOG(2, purchase_hour + 1)) AS INTEGER))
                ] || items
            ) 
            FILTER (WHERE idx = 2)
        ) AS last2bundle
        , FLATTEN(
            ARRAY_AGG(
                ARRAY[
                    FORMAT('category:%s', CRC32(TO_UTF8(item_category))),
                    FORMAT('price:%d', price_level),
                    FORMAT('hour:%d', CAST(TRUNCATE(LOG(2, purchase_hour + 1)) AS INTEGER))
                ] || items
            ) 
            FILTER (WHERE idx = 3)
        ) AS last3bundle
        , FLATTEN(
            ARRAY_AGG(
                ARRAY[
                    FORMAT('category:%s', CRC32(TO_UTF8(item_category))),
                    FORMAT('price:%d', price_level),
                    FORMAT('hour:%d', CAST(TRUNCATE(LOG(2, purchase_hour + 1)) AS INTEGER))
                ] || items
            ) 
            FILTER (WHERE idx = 4)
        ) AS last4bundle
        , FLATTEN(
            ARRAY_AGG(
                ARRAY[
                    FORMAT('category:%s', CRC32(TO_UTF8(item_category))),
                    FORMAT('price:%d', price_level),
                    FORMAT('hour:%d', CAST(TRUNCATE(LOG(2, purchase_hour + 1)) AS INTEGER))
                ] || items
            ) 
            FILTER (WHERE idx = 5)
        ) AS last5bundle
    FROM purchase_sequence_raw
    GROUP BY unique_id
)

, label_res AS (
    SELECT 
        open_id, user_id, trigger_type, bundle_id, trace_id, unique_id, ARBITRARY(event_time) AS event_time
        , FLATTEN(
            ARRAY_AGG(
                ARRAY[
                    FORMAT('item:%s,bkt:%d', c.item_id, CAST(TRUNCATE(LOG(2, item_goods_count * c.usd_price + 1)) AS INTEGER))
                    , FORMAT('type:%d,bkt:%d', CRC32(TO_UTF8(c.item_type)), CAST(TRUNCATE(LOG(2, item_goods_count * c.usd_price + 1)) AS INTEGER))
                ]
            )
        ) AS gift_contents
        , ARBITRARY(gift_contents) as raw_gift_contents
        , dt
        , bool_or(if_buy_boolean) as if_buy_boolean
        , bundle_price
        , MAX(label.max3pay) as max3pay
        , MAX(label.max7pay) as max7pay
    FROM label
    CROSS JOIN UNNEST(gift_contents) as g(item_goods_id, item_goods_count)
    LEFT JOIN hive."ds_bi_dw".dim_wgame_bundle_item_value_config as c
    ON IF(g.item_goods_id LIKE 'l_coin%','l_coin',g.item_goods_id) = c.item_id
    GROUP BY open_id, user_id, trigger_type, bundle_id, trace_id, dt, unique_id, bundle_price
)


SELECT
    l.open_id,
    l.user_id,
    l.event_time,
    l.trigger_type,
    l.bundle_price,
    CRC32(TO_UTF8(l.unique_id)),
    TRANSFORM(l.gift_contents, x -> CRC32(TO_UTF8(x))),
    TRANSFORM(p.last1bundle, x -> CRC32(TO_UTF8(x))),
    TRANSFORM(p.last2bundle, x -> CRC32(TO_UTF8(x))),
    TRANSFORM(p.last3bundle, x -> CRC32(TO_UTF8(x))),
    TRANSFORM(p.last4bundle, x -> CRC32(TO_UTF8(x))),
    TRANSFORM(p.last5bundle, x -> CRC32(TO_UTF8(x))),
    l.max3pay,
    l.max7pay,
    IF(l.if_buy_boolean, 1, 0),
    l.dt
FROM
    label_res AS l
LEFT JOIN purchase_sequence AS p 
    ON l.unique_id = p.unique_id