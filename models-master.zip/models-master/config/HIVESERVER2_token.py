import os

os.environ.update(
    {
        "HIVESERVER2_API_KEY": "9954b1025d9abd6f31b4a3cb6b190a9830Uop36Pa5m",
        "HIVESERVER2_API_SECRET": "UPM9rnL6tJ9G80l6Ci6ZcjdS55ZizCHTW3G0Wvx5Ks",
    }
)
