from tensorflow_serving.config import model_server_config_pb2
from tensorflow_serving.config.file_system_storage_path_source_pb2 import (
    FileSystemStoragePathSourceConfig,
)

_ = model_server_config_pb2.ModelConfigList(
    config=[
        model_server_config_pb2.ModelConfig(
            name="dynamic_pricing",
            base_path="/savedmodel/savedmodel/dynamic_pricing",
            model_platform="tensorflow",
            model_version_policy=FileSystemStoragePathSourceConfig.ServableVersionPolicy(
                specific=FileSystemStoragePathSourceConfig.ServableVersionPolicy.Specific(
                    versions=[1,2,3,4,5,6]
                )
            ),
            version_labels={"0.0.0": 1},
        )
    ]
)

modelconfig = model_server_config_pb2.ModelServerConfig(model_config_list=_)

with open("model.config", "w+") as f:
    f.write(modelconfig.__str__())
