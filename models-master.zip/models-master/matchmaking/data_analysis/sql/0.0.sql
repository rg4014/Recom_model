

DELETE FROM iceberg."ml_tmp_db"."solarland_matchmaking_feature_every_battle" WHERE dt = '{{ ds }}';

INSERT INTO iceberg."ml_tmp_db"."solarland_matchmaking_feature_every_battle"

-- 如果有武器配置表可以改成武器种类
WITH BASE AS (
    SELECT 
        "source_id.string", "battle_id.string","fire_num.bigint"
        , MAX("distance.int") AS "distance.int"
        , ARBITRARY("weapon_id.int") AS "weapon_id.int"
    FROM "iceberg"."game_ods"."10060_log"
    WHERE "event_time.string" BETWEEN '{{ ds }} 00:00:00' AND '{{ ds }} 24:00:00'
        AND "log_type.string" = 'solarland_weapon_hit_event'
        AND "mode_id.string" in ('5','7')
        AND "fire_num.bigint" is not null
    GROUP BY "source_id.string", "battle_id.string", "fire_num.bigint"
)

, hit_distance AS (
    SELECT 
        "source_id.string" AS source_id
        , "battle_id.string" AS battle_id 
        , ARRAY_AGG(
            CAST(
                ROW("distance.int", "fire_num.bigint", "weapon_id.int") AS ROW(distance integer, fire_num integer, weapon_id INTEGER)
            ) ORDER BY "fire_num.bigint"
        ) AS distance
    FROM BASE
    GROUP BY "source_id.string", "battle_id.string"
)

, hit_distance2 AS (
    SELECT 
        source_id
        , battle_id
        , TRANSFORM(
            NGRAMS(distance, 2),
            x -> CAST(ROW(x[2][1], x[2][2] - x[1][2], x[2][3]) AS ROW(distance integer, fire_num integer, weapon_id INTEGER)) 
        ) AS hit
    FROM hit_distance
    WHERE cardinality(distance) >= 2
)

, tmp AS (
    SELECT 
        source_id AS open_id
        , battle_id
        , dim.type AS weapon_id
        , CONCAT_WS(
            U&'\0004',
            FORMAT('%shitrate%d', dim.type, CAST(FLOOR(CAST(COUNT(1) AS DOUBLE) / CAST(SUM(fire_num) AS DOUBLE) * 30) AS INTEGER)),
            FORMAT('%shitscore%d', dim.type, CAST(FLOOR(LOG(1.5, CAST(SUM(distance) AS DOUBLE)/ CAST(SUM(fire_num) AS DOUBLE) + 1)) AS INTEGER))
        ) AS feature
    FROM hit_distance2
    CROSS JOIN UNNEST(hit) AS t(distance, fire_num, weapon_id)
    INNER JOIN hive."10060_bi_dw".dim_weapon_id  AS dim
        ON dim.id = t.weapon_id
    GROUP BY source_id, battle_id, dim.type
)

SELECT 
    open_id
    , battle_id
    , U&'weapon_last_battle\0003' || CONCAT_WS(U&'\0004', ARRAY_AGG(feature)) AS feature
    , 'weapon_score_last_battle'
    , '{{ ds }}'
FROM tmp
GROUP BY open_id, battle_id

;

INSERT INTO iceberg."ml_tmp_db"."solarland_matchmaking_feature_every_battle"

WITH hit_event AS (
    SELECT 
        "source_id.string" AS source_id
        , "battle_id.string" AS battle_id 
        , IF("open_id.string" = '', 'NPC@' || "my_nickname.string", "open_id.string") AS target_id
        , "distance.int" AS distance
        , "fire_num.bigint" AS fire_num
        , "isheadshot.bigint" AS isheadshot
    FROM "iceberg"."game_ods"."10060_log"
    WHERE "event_time.string" BETWEEN '{{ ds }} 00:00:00' AND '{{ ds }} 24:00:00'
        AND "log_type.string" = 'solarland_weapon_hit_event'
        AND "mode_id.string" in ('5','7')
        AND "fire_num.bigint" is not null
)

, hit_stats AS (
    SELECT 
        source_id
        , battle_id
        , CAST(SUM(distance) AS DOUBLE) AS total_distance
        , MIN_BY(fire_num, IF(isheadshot = 1, fire_num, 1e7)) - MIN(fire_num) AS shot_takes_for_headshot
        , CAST(SUM(isheadshot) AS DOUBLE) AS headshot_num
        , CAST(COUNT(1) AS DOUBLE) AS hit_num
        , CAST(MAX(fire_num) AS DOUBLE) AS max_fire_num
    FROM hit_event
    GROUP BY source_id, battle_id, target_id
)


SELECT 
    source_id AS open_id
    , battle_id
    , CONCAT_WS(
        U&'\0002'
        , FORMAT(U&'avg_valid_dist_last_battle\0003%.2f', SUM(total_distance) / SUM(hit_num))
        , FORMAT(U&'avg_stfh_last_battle\0003%.2f', AVG(shot_takes_for_headshot))
        , FORMAT(U&'head_shot_rate_last_battle\0003%.2f', SUM(headshot_num) / SUM(hit_num))
        , FORMAT(U&'hit_rate_last_battle\0003%.2f', SUM(hit_num) / MAX(max_fire_num))
    )
    , 'stats_last_battle'
    , '{{ ds }}'
FROM hit_stats
GROUP BY source_id, battle_id