CREATE TABLE IF NOT EXISTS hive.ml_tmp_db.solarland_battle_sample_240130 (
    event_time VARCHAR,
    battle_id VARCHAR,
    team_id VARCHAR,
    ticket_id VARCHAR,
    app_version VARCHAR,
    open_id VARCHAR,
    feature VARCHAR,

    is_retention INTEGER,
    battle_fight_num INTEGER,
    is_battle_number_lift INTEGER,
    is_damage_amount_lift INTEGER,
    is_survival_time_lift INTEGER,
    is_ka_number_lift INTEGER,
    
    dt VARCHAR
) WITH (
    format = 'PARQUET',
    partitioned_by = ARRAY['dt']
);

DELETE FROM hive.ml_tmp_db.solarland_battle_sample_240130
WHERE dt = '{{ ds.to_date_string() }}';

INSERT INTO hive.ml_tmp_db.solarland_battle_sample_240130

WITH raw AS (
    SELECT 
        a.battle_id
        , a.team_id
        , a.elo
        , c.ticket_id
        , a.event_time
        , a.open_id
        , a.app_version
        
        , DATE_DIFF('day', TRY_CAST(d.role_create_time AS TIMESTAMP), TRY_CAST( a.event_time AS TIMESTAMP)) AS lifespan
        , DATE_DIFF('hour', c.event_time, a.event_time) AS fade_time
        , ROW_NUMBER() OVER (PARTITION BY a.battle_id, a.open_id ORDER BY c.event_time DESC) AS rnk
        , COUNT() OVER (PARTITION BY a.battle_id, a.open_id) AS battle_number

        , b.safearea_rank
        , b.rank_team
        , b.hit_number
        , b.hited_number
        , b.headshot_number
        , b.headshoted_number
        , b.damage_amount
        , b.damage_taken_amount
        , b.save_number
        , b.weapon1
        , b.weapon2
        , b.character_id
        , b.kill_number
        , b.assist_number 
        , b.dead_number
        , b.death_number
        , b.survival_time
        , b.battle_fight_num

        , ROUND(IF( b.shoot_number > 0 , CAST(b.hit_number AS DOUBLE) / CAST(b.shoot_number AS DOUBLE), 0.0), 2) as hit_rate
        , ROUND(IF( b.shoot_number > 0 , CAST(b.headshot_number AS DOUBLE) / CAST(b.shoot_number AS DOUBLE), 0.0), 2) as headshot_rate
        , ROUND(CAST(b.kill_number + b.assist_number AS DOUBLE) / CAST(b.survival_time AS DOUBLE) * 60 * 3, 2) AS ka_per_3min

        , TRY_CAST(a.kill_number + a.assist_number AS DOUBLE) AS this_game_ka_number
        , TRY_CAST(a.damage_amount AS DOUBLE) AS this_game_damage_amount
        , TRY_CAST(a.survival_time AS DOUBLE) AS this_game_survival_time
        , TRY_CAST(a.battle_fight_num AS DOUBLE) AS this_game_battle_fight_num
    FROM (
        SELECT *
        FROM hive."10060_oss_bi_dw".solarland_battle_end_server
        WHERE dt = '{{ ds.add(days = 0).to_date_string() }}'
            AND match_rule_id in (2, 3, 4)
            AND warm_game_id = 0
            AND survival_time > 0
            AND pkg != 'com.farlightgames.farlight84.gray'
            -- AND app_version LIKE '2.%'
    ) AS a
    LEFT JOIN (
        SELECT *
        FROM hive."10060_oss_bi_dw".solarland_battle_end_server
        WHERE dt BETWEEN '{{ ds.add(days = -2).to_date_string() }}' AND '{{ ds.add(days = 0).to_date_string() }}'
            AND match_rule_id in (2, 3, 4)
            AND warm_game_id = 0
            AND survival_time > 0
            AND pkg != 'com.farlightgames.farlight84.gray'
    ) AS b
    ON a.open_id = b.open_id
        AND a.event_time > b.event_time
    LEFT JOIN (
        SELECT *
        FROM hive."10060_oss_bi_dw".solarland_match_end
        WHERE dt = '{{ ds.add(days = 0).to_date_string() }}'
            AND match_rule_id in (2, 3, 4)
    ) AS c
    ON c.battle_id = a.battle_id
        AND c.open_id = a.open_id
    INNER JOIN kudu."10060_bi_ods".total_role_attr_all AS d
    ON a.open_id = d.acc_id
)


, feature AS (
    SELECT 
        event_time
        , battle_id
        , team_id
        , ticket_id
        , open_id

        , ARBITRARY(app_version) AS app_version

        , IF(ARBITRARY(this_game_damage_amount / this_game_survival_time) > SUM(damage_amount) / SUM(survival_time), 1, 0) AS is_damage_amount_lift
        , IF(ARBITRARY(this_game_survival_time) > AVG(survival_time), 1, 0) AS is_survival_time_lift
        , IF(ARBITRARY(this_game_ka_number / this_game_survival_time) > SUM(kill_number + assist_number) / SUM(survival_time), 1, 0) AS is_ka_number_lift
        , IF(ARBITRARY(this_game_battle_fight_num) > AVG(battle_fight_num), 1, 0) AS is_battle_number_lift
        , ARBITRARY(this_game_battle_fight_num) AS battle_fight_num

        , CONCAT_WS(
            U&'\0002'
            , FORMAT(U&'r_elo\0003%d', ARBITRARY(elo))
            , FORMAT(U&'r_lifespan\0003%d', ARBITRARY(lifespan))
            , FORMAT(U&'r_his_battle_number_3d\0003%d', ARBITRARY(battle_number))

            , FORMAT(U&'r_fade_time\0003%s', CONCAT_WS(U&'\0004', ARRAY_AGG(FORMAT('%d', fade_time) ORDER BY rnk DESC)))
            , FORMAT(U&'r_safearea_rank\0003%s', CONCAT_WS(U&'\0004', ARRAY_AGG(FORMAT('%d', safearea_rank) ORDER BY rnk DESC)))
            , FORMAT(U&'r_rank_team\0003%s', CONCAT_WS(U&'\0004', ARRAY_AGG(FORMAT('%d', rank_team) ORDER BY rnk DESC)))
            
            , FORMAT(U&'r_hit_rate\0003%s', CONCAT_WS(U&'\0004', ARRAY_AGG(FORMAT('%.2f', hit_rate) ORDER BY rnk DESC)))
            , FORMAT(U&'r_headshot_rate\0003%s', CONCAT_WS(U&'\0004', ARRAY_AGG(FORMAT('%.2f', headshot_rate) ORDER BY rnk DESC)))

            , FORMAT(U&'r_hit_number\0003%s', CONCAT_WS(U&'\0004', ARRAY_AGG(FORMAT('%d', hit_number) ORDER BY rnk DESC)))
            , FORMAT(U&'r_hited_number\0003%s', CONCAT_WS(U&'\0004', ARRAY_AGG(FORMAT('%d', hited_number) ORDER BY rnk DESC)))
            , FORMAT(U&'r_headshot_number\0003%s', CONCAT_WS(U&'\0004', ARRAY_AGG(FORMAT('%d', headshot_number) ORDER BY rnk DESC)))
            , FORMAT(U&'r_headshoted_number\0003%s', CONCAT_WS(U&'\0004', ARRAY_AGG(FORMAT('%d', headshoted_number) ORDER BY rnk DESC)))
            , FORMAT(U&'r_damage_amount\0003%s', CONCAT_WS(U&'\0004', ARRAY_AGG(FORMAT('%d', damage_amount) ORDER BY rnk DESC)))
            , FORMAT(U&'r_damage_taken_amount\0003%s', CONCAT_WS(U&'\0004', ARRAY_AGG(FORMAT('%d', damage_taken_amount) ORDER BY rnk DESC)))
            , FORMAT(U&'r_save_number\0003%s', CONCAT_WS(U&'\0004', ARRAY_AGG(FORMAT('%d', save_number) ORDER BY rnk DESC)))

            , FORMAT(U&'r_weapon1\0003%s', CONCAT_WS(U&'\0004', ARRAY_AGG(FORMAT('%d', weapon1) ORDER BY rnk DESC)))
            , FORMAT(U&'r_weapon2\0003%s', CONCAT_WS(U&'\0004', ARRAY_AGG(FORMAT('%d', weapon2) ORDER BY rnk DESC)))
            , FORMAT(U&'r_character_id\0003%s', CONCAT_WS(U&'\0004', ARRAY_AGG(FORMAT('%d', character_id) ORDER BY rnk DESC)))

            , FORMAT(U&'r_kill_number\0003%s', CONCAT_WS(U&'\0004', ARRAY_AGG(FORMAT('%d', kill_number) ORDER BY rnk DESC)))
            , FORMAT(U&'r_assist_number\0003%s', CONCAT_WS(U&'\0004', ARRAY_AGG(FORMAT('%d', assist_number) ORDER BY rnk DESC)))
            , FORMAT(U&'r_dead_number\0003%s', CONCAT_WS(U&'\0004', ARRAY_AGG(FORMAT('%d', dead_number) ORDER BY rnk DESC)))
            , FORMAT(U&'r_death_number\0003%s', CONCAT_WS(U&'\0004', ARRAY_AGG(FORMAT('%d', death_number) ORDER BY rnk DESC)))
            
            , FORMAT(U&'r_ka_per_3min\0003%s', CONCAT_WS(U&'\0004', ARRAY_AGG(FORMAT('%.2f', ka_per_3min) ORDER BY rnk DESC)))
            , FORMAT(U&'r_survival_time\0003%s', CONCAT_WS(U&'\0004', ARRAY_AGG(FORMAT('%d', survival_time) ORDER BY rnk DESC)))
        ) As feature
    FROM raw
    WHERE rnk <= 5
    GROUP BY 1, 2, 3, 4, 5
)

SELECT 
    feature.event_time
    , feature.battle_id
    , feature.team_id
    , feature.ticket_id

    , feature.app_version
    , feature.open_id

    , feature.feature
    
    , IF(retention.open_id is not null and feature.event_time < retention.event_time, 1, 0) AS is_retention
    , battle_fight_num
    , is_battle_number_lift
    , is_damage_amount_lift
    , is_survival_time_lift
    , is_ka_number_lift
    , '{{ ds.to_date_string() }}' AS dt
FROM feature
LEFT JOIN (
    SELECT open_id, MAX(event_time) AS event_time
    FROM hive."10060_oss_bi_dw".solarland_battle_end_server
    WHERE dt BETWEEN '{{ ds.add(days = 0).to_date_string() }}' AND '{{ ds.add(days = 1).to_date_string() }}'
        AND match_rule_id in (2, 3, 4)
    GROUP BY 1
) AS retention
ON feature.open_id = retention.open_id 