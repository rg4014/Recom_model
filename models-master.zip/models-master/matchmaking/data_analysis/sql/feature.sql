WITH BASE AS (
    SELECT 
        "source_id.string"
        , "battle_id.string"
        , "fire_num.bigint"
        , MAX("distance.int") AS "distance.int"
        , ARBITRARY("weapon_id.int") AS "weapon_id.int"
        , ROW_NUMBER() OVER (PARTITION BY "source_id.string" ORDER BY split_part("battle_id.string",'_',2) DESC) AS rnk
    FROM "iceberg"."game_ods"."10060_log"
    WHERE "event_time.string" BETWEEN '{{ macro.ds_add(ds, -1) }} 00:00:00' AND '{{ macro.ds_add(ds, 1) }} 24:00:00'
        AND "log_type.string" = 'solarland_weapon_hit_event'
        AND "mode_id.string" in ('5','7')
        AND "fire_num.bigint" is not null
    GROUP BY "source_id.string", "battle_id.string", "fire_num.bigint"
)

, hit_distance AS (
    SELECT 
        "source_id.string" AS source_id
        , ARRAY_AGG(
            CAST(
                ROW("distance.int", "fire_num.bigint", "weapon_id.int", rnk) 
                AS 
                ROW(distance integer, fire_num integer, weapon_id INTEGER, rnk SMALLINT)
            ) ORDER BY rnk, "fire_num.bigint"
        ) AS distance
    FROM BASE
    WHERE rnk <= 3
    GROUP BY "source_id.string"
)

, hit_distance2 AS (
    SELECT 
        source_id
        , TRANSFORM(
            NGRAMS(distance, 2),
            x -> CAST(
                ROW(x[2][1], x[2][2] - IF(x[1][4] = x[2][4], x[1][2], 0) + 1, x[2][3]) 
                AS 
                ROW(distance integer, fire_num integer, weapon_id INTEGER)
            ) 
        ) AS hit
    FROM hit_distance
    WHERE cardinality(distance) >= 2
)


, tmp AS (
    SELECT 
        source_id AS open_id
        -- , dim.type AS weapon_id
        , CONCAT_WS(
            U&'\0004',
            FORMAT('%s_hitrate%d', dim.type, CAST(FLOOR(LOG(2, 1 + 1022 * CAST(COUNT(1) AS DOUBLE) / CAST(SUM(fire_num) AS DOUBLE))) AS INTEGER)),
            FORMAT('%s_avg_dist_per_hit%d', dim.type, CAST(FLOOR(LOG(1.5, CAST(SUM(distance) AS DOUBLE)/ CAST(COUNT(1) AS DOUBLE))) AS INTEGER))
        ) AS feature_bucketed
        , CONCAT_WS(
            U&'\0004',
            FORMAT('%s_hitrate%.2f', dim.type, CAST(COUNT(1) AS DOUBLE) / CAST(SUM(fire_num) AS DOUBLE)),
            FORMAT('%s_avg_dist_per_hit%.2f', dim.type, CAST(SUM(distance) AS DOUBLE)/ CAST(COUNT(1) AS DOUBLE))
        ) AS feature
    FROM hit_distance2
    CROSS JOIN UNNEST(hit) AS t(distance, fire_num, weapon_id)
    INNER JOIN hive."10060_bi_dw".dim_weapon_id  AS dim
        ON dim.id = t.weapon_id
    GROUP BY source_id, dim.type
)

SELECT 
    open_id
    , U&'weapon_p3br\0003' || CONCAT_WS(U&'\0004', ARRAY_AGG(feature)) || U&'\0002weapon_p3br_bkt\0003' || CONCAT_WS(U&'\0004', ARRAY_AGG(feature_bucketed))
    , 'weapon_stats'
    , '{{ ds }}'
    , current_timestamp
FROM tmp
GROUP BY open_id;



