import tensorflow as tf


class DenseHashedCrossing(tf.keras.layers.Layer):
    def __init__(self, num_bins, **kwargs):
        super().__init__(**kwargs)
        self._num_bins = num_bins

    def call(self, inputs):
        cross = tf.sparse.cross_hashed(inputs, num_buckets=self._num_bins)
        cross = tf.sparse.to_dense(cross)
        return cross
