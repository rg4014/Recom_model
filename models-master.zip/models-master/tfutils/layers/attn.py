import tensorflow as tf


class BatchNormSelfAttention(tf.keras.layers.Layer):
    def __init__(self, **kwargs):
        super().__init__()
        self.mha = tf.keras.layers.MultiHeadAttention(**kwargs)
        self.norm = tf.keras.layers.BatchNormalization()
        self.add = tf.keras.layers.Add()

    def call(self, x):
        attn_output = self.mha(query=x, value=x, key=x)
        x = self.add([x, attn_output])
        x = self.norm(x)
        return x
    
class BatchNormAttention(tf.keras.layers.Layer):
    def __init__(self, **kwargs):
        super().__init__()
        self.mha = tf.keras.layers.MultiHeadAttention(**kwargs)
        self.norm = tf.keras.layers.BatchNormalization()
        self.add = tf.keras.layers.Add()

    def call(self, x, context):
        attn_output = self.mha(query=x, value=context, key=context)
        x = self.add([x, attn_output])
        x = self.norm(x)
        return x


class BatchNormFeedForward(tf.keras.layers.Layer):
    def __init__(self, d_model, dff, dropout_rate=0.1):
        super().__init__()
        self.seq = tf.keras.Sequential(
            [
                tf.keras.layers.Dense(dff, activation="relu"),
                tf.keras.layers.Dense(d_model),
                tf.keras.layers.Dropout(dropout_rate),
            ]
        )
        self.add = tf.keras.layers.Add()
        self.norm = tf.keras.layers.BatchNormalization()

    def call(self, x):
        x = self.add([x, self.seq(x)])
        x = self.norm(x)
        return x


class BatchNormTransformerEncoder(tf.keras.layers.Layer):
    def __init__(self, d_model, num_heads, dff, dropout_rate=0.1, **kwargs):
        super().__init__(**kwargs)
        self.self_attention = BatchNormSelfAttention(
            num_heads=num_heads, key_dim=d_model, dropout=dropout_rate
        )
        self.ffn = BatchNormFeedForward(d_model, dff)
        
        self.d_model = d_model
        self.num_heads = num_heads
        self.dff = dff
        self.dropout_rate = dropout_rate

    def call(self, x):
        x = self.self_attention(x)
        x = self.ffn(x)
        return x
    
    def get_config(self):
        config = super().get_config()
        config.update({
            'd_model' : self.d_model,
            'num_heads' : self.num_heads,
            'dff' : self.dff,
            'dropout_rate' : self.dropout_rate
        })
        return config

class BatchNormTransformerDecoder(tf.keras.layers.Layer):
    def __init__(self, d_model, num_heads, dff, dropout_rate=0.1, **kwargs):
        super().__init__(**kwargs)
        self.attention = BatchNormAttention(
            num_heads=num_heads, key_dim=d_model, dropout=dropout_rate
        )
        self.ffn = BatchNormFeedForward(d_model, dff)

    def call(self, x, context):
        x = self.attention(x, context)
        x = self.ffn(x)
        return x