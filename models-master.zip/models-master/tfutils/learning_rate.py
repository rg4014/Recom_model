import tensorflow as tf

def simple_lrschedule(epoch, lr):
    if epoch < 5:
        pass
    elif epoch < 20:
        lr *= tf.math.exp(-0.05)
    else:
        lr *= tf.math.exp(-0.1)
    return lr