import tensorflow as tf

from tfutils.layers.cross import DenseHashedCrossing


def int64_to_embedding(shape, vocab, embedding_size, name):
    i = tf.keras.Input(shape=shape, name=name, dtype=tf.int64)
    x = tf.keras.layers.IntegerLookup(
        vocabulary=vocab, oov_token=0, name=f"lookup_{name}"
    )(i)
    x = tf.keras.layers.Embedding(
        input_dim=len(vocab) + 1,
        output_dim=embedding_size,
        mask_zero=True,
        name=f"emb_{name}",
    )(x)
    return i, x

def uint64_to_embedding(shape, vocab, embedding_size, name, mask=None):
    i = tf.keras.Input(shape=shape, name=name, dtype=tf.uint64)
    
    if mask:
        x = tf.bitwise.bitwise_and(i, mask)
        x = tf.keras.layers.IntegerLookup(
            vocabulary=vocab, oov_token=0, name=f"lookup_{name}"
        )(x)
    else:
        x = tf.keras.layers.IntegerLookup(
            vocabulary=vocab, oov_token=0, name=f"lookup_{name}"
        )(i)
    
    x = tf.keras.layers.Embedding(
        input_dim=len(vocab) + 1,
        output_dim=embedding_size,
        mask_zero=True,
        name=f"emb_{name}",
    )(x)
    return i, x


def cross_to_embedding(inputs, num_bins, embedding_size, names):
    name = "cross_{}".format("_".join(names))

    shape = 1
    for i in inputs:
        shape *= i.shape[1]

    x = DenseHashedCrossing(num_bins=num_bins, name=name)(inputs)
    x = tf.keras.layers.Reshape((shape,))(x)
    x = tf.keras.layers.Embedding(
        input_dim=num_bins,
        output_dim=embedding_size,
        mask_zero=True,
        name=f"emb_{name}",
    )(x)
    return x
